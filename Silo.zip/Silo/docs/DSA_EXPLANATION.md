# DSA in Silo — where each concept lives and why

| Concept | File | Used for | Complexity |
|---|---|---|---|
| **Merge Sort** (hand-written, stable) | `algo/DonationMergeSort.java` | Ranking donations (Donations page, Dashboard priority list, scheduling list); also ordering pickups and near-expiry food | O(n log n) best, average, worst; O(n) extra space |
| **Priority rule** | `algo/DonationPriority.java` | The comparator Merge Sort uses | O(1) per comparison |
| **Searching** (linear, case-insensitive "contains") | `algo/Search.java` | Search boxes on Donations, Volunteers, Recipients | O(n·m) for n records, m searched fields |
| **Queue** | `algo/PickupQueue.java` | Scheduled pickups processed earliest-time-first ("Process next in queue"); FIFO among equal times | enqueue O(n) (sorted insertion), peek O(1), dequeue O(n) shift |
| **Stack** (LIFO) | `algo/ActionHistory.java` | "Undo last action" | push/pop O(1) |
| **ArrayList** | `service/SiloService.java` | Every record collection | get O(1), add amortised O(1) |

## Priority rule (consistent everywhere)
1. Higher perishability first (5 = spoils fastest)
2. Earlier best-before date
3. Shorter pickup distance
4. Lower ID (so the order is fully deterministic)

## Merge Sort in one paragraph
Split the list in half until each piece has 0–1 items, then merge pieces back by repeatedly taking the smaller front item. When two items compare equal the left one is taken first, which makes the sort **stable**. The input list is never modified. No `Collections.sort` / `List.sort` is used for ranking — `DonationMergeSort` is the only sorter (the test suite compares it against `Collections.sort` on random data to prove correctness).

## Why a sorted-insertion queue?
Pickups arrive in any order but must be processed by scheduled time. Inserting each new pickup at its correct position keeps the front of the queue always the next one to process. For the size of a community food bank (hundreds, not millions) O(n) insertion is perfectly fine and easy to explain; a binary heap would be the upgrade for very large volumes.
