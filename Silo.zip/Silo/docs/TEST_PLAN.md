# Test plan and feature checklist

Legend: **Done** = implemented *and* covered by an automated test or a rendered-UI check; **Done (manual)** = implemented, checked only by launching/rendering the UI; **Pending** = not built.

| Feature | Status | How it was checked |
|---|---|---|
| Donation add / edit / cancel with validation | Done | `ServiceTest` (invalid inputs, edit vs. distributed qty) |
| Search + status filter | Done | `ServiceTest.searchAndStatusFilterWork`, `AlgorithmTest` |
| Merge Sort priority | Done | `AlgorithmTest` (rules, stability, empty/single, random vs. reference) |
| Pickup scheduling, conflicts, past/after-expiry rejection | Done | `ServiceTest.volunteerConflicts...` |
| Pickup queue (earliest first, rebuilt after restart) | Done | `AlgorithmTest`, `ServiceTest.queueProcesses...` |
| Volunteer add / edit / deactivate | Done | `ServiceTest` |
| Recipients + distribution limits | Done | `ServiceTest.cannotDistributeMore...` |
| Full workflow Available → Delivered | Done | `ServiceTest.fullWorkflow...` |
| Undo (stack) | Done | `ServiceTest.undoReverses...`, `AlgorithmTest` |
| Reports (per-unit totals, status counts, near-expiry, filters) | Done | `ServiceTest`, `StorageAndExportTest` |
| CSV export | Done | `StorageAndExportTest` (quoting, BOM, bad path); file-chooser dialog itself: Done (manual) |
| Persistence across restart; special characters in text | Done | `ServiceTest`, `StorageAndExportTest` |
| All six pages open and show real data / empty states | Done (manual) | Rendered with `ScreenshotTool` under a virtual display; app launched with `SiloApp.main` |
| Form dialogs show validation errors inline | Done (manual) | Rendered; the same service validation is unit-tested |
| Maven build | **Not verified** | No Maven Central access in the build environment |
| Login, roles, PostgreSQL, REST API | **Pending (out of scope)** | See README limitations |
| Status-history table | **Pending** | Activity log used instead |

## Manual walk-through for the demo
1. Dashboard → **Load sample data**.
2. Donations: note the ranking (5 = very perishable first). Search "banana".
3. Pickups: **+ Schedule pickup** with a past time → error shown; with a valid time → success. Schedule a second one for the same volunteer 30 min later → conflict message.
4. **Process next in queue** → earliest pickup becomes Picked up (queue demo).
5. Recipients → **Record distribution** of more than what's left → error; valid amount → history row.
6. **Undo last action** (sidebar) to show the stack.
7. Reports → Distributions → **Export CSV**, open in Excel.
